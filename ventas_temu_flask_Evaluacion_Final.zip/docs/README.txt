SEMANA 13
La versión dinámica del proyecto utiliza Flask + MySQL.
GitHub Pages sirve únicamente como publicación visual estática; el CRUD real de Productos se comprueba ejecutando Flask y MySQL localmente.
